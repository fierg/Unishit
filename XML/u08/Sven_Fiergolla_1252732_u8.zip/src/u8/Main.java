package u8;

public class Main {

	public static void main(String[] args) {
		
		KMeans.doKMeansClustering(2000, 1, false ,"/filepath " /* optional*/);
	}
}
